import { createHmac } from 'node:crypto';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { EdrvAdapter } from './edrv.adapter';
import { ChargingProviderError } from '../provider';

const API_KEY = 'edrv_test_key';
const WEBHOOK_SECRET = 'whsec_edrv_test';

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json' },
  });
}

/** eDRV wraps successful payloads in { result: … }. */
function wrapped(result: unknown, status = 200): Response {
  return jsonResponse({ result }, status);
}

function makeAdapter(
  fetchImpl: typeof fetch,
  overrides: Partial<ConstructorParameters<typeof EdrvAdapter>[0]> = {},
) {
  return new EdrvAdapter({
    apiKey: API_KEY,
    webhookSecret: WEBHOOK_SECRET,
    energyUnit: 'Wh',
    fetchImpl,
    ...overrides,
  });
}

describe('EdrvAdapter — construction', () => {
  it('refuses to construct without an explicit energy unit', () => {
    expect(
      () =>
        new EdrvAdapter({
          apiKey: API_KEY,
          // @ts-expect-error — deliberately omitted; this must not be defaultable
          energyUnit: undefined,
        }),
    ).toThrow(/energyUnit/);
  });

  it('requires an api key', () => {
    expect(() => new EdrvAdapter({ apiKey: '', energyUnit: 'Wh' })).toThrow(/apiKey/);
  });
});

describe('EdrvAdapter — energy units', () => {
  // The single highest-consequence behaviour in this file. eDRV reporting Wh
  // while we assume kWh bills a 20 kWh charge as 20,000 kWh.
  it('converts Wh to kWh', async () => {
    const fetchImpl = vi.fn(async () =>
      wrapped({ _id: 's1', status: 'ended', start_date: 'x', energy: 18440 }),
    ) as unknown as typeof fetch;

    const details = await makeAdapter(fetchImpl, { energyUnit: 'Wh' }).getSessionDetails({
      providerSessionId: 's1',
    });
    expect(details.energyKwh).toBe(18.44);
  });

  it('passes kWh through untouched', async () => {
    const fetchImpl = vi.fn(async () =>
      wrapped({ _id: 's1', status: 'ended', start_date: 'x', energy: 18.44 }),
    ) as unknown as typeof fetch;

    const details = await makeAdapter(fetchImpl, { energyUnit: 'kWh' }).getSessionDetails({
      providerSessionId: 's1',
    });
    expect(details.energyKwh).toBe(18.44);
  });

  it('treats missing, negative and non-finite energy as zero, never NaN', async () => {
    for (const value of [undefined, null, -5, Number.NaN, Number.POSITIVE_INFINITY]) {
      const fetchImpl = vi.fn(async () =>
        wrapped({ _id: 's1', status: 'ended', energy: value }),
      ) as unknown as typeof fetch;
      const details = await makeAdapter(fetchImpl).getSessionDetails({ providerSessionId: 's1' });
      expect(details.energyKwh).toBe(0);
    }
  });
});

describe('EdrvAdapter — sessions', () => {
  it('unwraps the { result } envelope', async () => {
    const fetchImpl = vi.fn(async () =>
      wrapped({ _id: 'sess_123', start_date: '2026-08-08T10:00:00Z' }),
    ) as unknown as typeof fetch;

    const ref = await makeAdapter(fetchImpl).startCharging('conn_1', {
      sessionId: 'evr-1',
      userId: 'u-1',
      connectorId: 'conn_1',
      providerUserRef: 'edrv_user_1',
    });

    expect(ref.providerSessionId).toBe('sess_123');
    expect(ref.startedAt).toBe('2026-08-08T10:00:00Z');
  });

  it('sends connector + eDRV user id, and round-trips our session id', async () => {
    const fetchImpl = vi.fn(async () => wrapped({ _id: 'sess_1' })) as unknown as typeof fetch;

    await makeAdapter(fetchImpl).startCharging('conn_1', {
      sessionId: 'evr-42',
      userId: 'u-1',
      connectorId: 'conn_1',
      providerUserRef: 'edrv_user_9',
    });

    const [url, init] = (fetchImpl as unknown as ReturnType<typeof vi.fn>).mock.calls[0] as [
      string,
      RequestInit,
    ];
    expect(url).toBe('https://api.edrv.io/v1.1/sessions');
    expect(init.method).toBe('POST');
    expect((init.headers as Record<string, string>)['authorization']).toBe(`Bearer ${API_KEY}`);

    const body = JSON.parse(init.body as string) as Record<string, unknown>;
    expect(body['connector']).toBe('conn_1');
    expect(body['user']).toBe('edrv_user_9');
    expect(body['meta_data']).toEqual({ evrute_session_id: 'evr-42' });
  });

  it('fails with a message naming the mapping when providerUserRef is absent', async () => {
    const fetchImpl = vi.fn() as unknown as typeof fetch;
    await expect(
      makeAdapter(fetchImpl).startCharging('conn_1', {
        sessionId: 'evr-1',
        userId: 'u-1',
        connectorId: 'conn_1',
      }),
    ).rejects.toThrow(/provider_user_ref/);
    // and must not have called the API at all
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it('stops via GET, not POST', async () => {
    // eDRV models stop as a GET with a side effect. If someone "corrects"
    // this to POST, every stop silently 404s and sessions never close.
    const fetchImpl = vi.fn(async () => new Response('', { status: 200 })) as unknown as typeof fetch;

    await makeAdapter(fetchImpl).stopCharging({ providerSessionId: 'sess_1' });

    const [url, init] = (fetchImpl as unknown as ReturnType<typeof vi.fn>).mock.calls[0] as [
      string,
      RequestInit,
    ];
    expect(url).toBe('https://api.edrv.io/v1.1/sessions/sess_1/stop');
    expect(init.method).toBe('GET');
  });

  it('throws rather than inventing a reservation eDRV cannot honour', async () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    await expect(
      adapter.reserveConnector('c1', { startsAt: new Date(), expiresAt: new Date() }),
    ).rejects.toThrow(/does not support reservations/);
  });
});

describe('EdrvAdapter — error classification', () => {
  it.each([408, 429, 500, 502, 503, 504])('marks %i retryable', async (status) => {
    const fetchImpl = vi.fn(async () => new Response('nope', { status })) as unknown as typeof fetch;
    const error = await makeAdapter(fetchImpl)
      .getConnectorStatus('c1')
      .catch((e: unknown) => e);
    expect(error).toBeInstanceOf(ChargingProviderError);
    expect((error as ChargingProviderError).options.retryable).toBe(true);
  });

  it.each([400, 401, 403, 404, 422])('marks %i NOT retryable', async (status) => {
    const fetchImpl = vi.fn(async () => new Response('nope', { status })) as unknown as typeof fetch;
    const error = await makeAdapter(fetchImpl)
      .getConnectorStatus('c1')
      .catch((e: unknown) => e);
    expect((error as ChargingProviderError).options.retryable).toBe(false);
  });

  it('turns a network throw into a retryable error', async () => {
    const fetchImpl = vi.fn(async () => {
      throw new Error('ECONNRESET');
    }) as unknown as typeof fetch;
    const error = await makeAdapter(fetchImpl)
      .getConnectorStatus('c1')
      .catch((e: unknown) => e);
    expect((error as ChargingProviderError).options.retryable).toBe(true);
  });
});

describe('EdrvAdapter — connector status mapping', () => {
  it.each([
    ['Available', 'available'],
    ['Preparing', 'occupied'],
    ['Charging', 'occupied'],
    ['SuspendedEV', 'occupied'],
    ['Finishing', 'occupied'],
    ['Reserved', 'reserved'],
    ['Unavailable', 'offline'],
    ['Faulted', 'faulted'],
  ])('maps %s -> %s', async (raw, expected) => {
    const fetchImpl = vi.fn(async () => wrapped({ _id: 'c1', status: raw })) as unknown as typeof fetch;
    await expect(makeAdapter(fetchImpl).getConnectorStatus('c1')).resolves.toBe(expected);
  });

  it('maps an unknown status to offline, never available', async () => {
    // Reporting an unknown state as free sends a driver to a charger that
    // cannot serve them. Fail closed.
    const fetchImpl = vi.fn(async () =>
      wrapped({ _id: 'c1', status: 'SomeNewStatusEdrvAdded' }),
    ) as unknown as typeof fetch;
    await expect(makeAdapter(fetchImpl).getConnectorStatus('c1')).resolves.toBe('offline');
  });
});

describe('EdrvAdapter — webhook signatures', () => {
  const NOW = 1_786_000_000_000;

  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(NOW);
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  const body = JSON.stringify({ event: 'session.ended', data: { _id: 's1' } });
  const sign = (payload: string, secret = WEBHOOK_SECRET) =>
    createHmac('sha256', secret).update(payload, 'utf8').digest('hex');

  function header(timestamp: number, digest: string) {
    return `t=${timestamp},v1=${digest}`;
  }

  it('accepts a correctly signed, fresh webhook', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    expect(adapter.verifyWebhookSignature(body, header(NOW, sign(body)))).toBe(true);
  });

  it('rejects a forged digest', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    expect(adapter.verifyWebhookSignature(body, header(NOW, 'a'.repeat(64)))).toBe(false);
  });

  it('rejects a digest made with the wrong secret', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    expect(adapter.verifyWebhookSignature(body, header(NOW, sign(body, 'wrong')))).toBe(false);
  });

  it('rejects a REPLAYED webhook outside the tolerance window', () => {
    // A valid signature stays valid forever without a timestamp check, and a
    // replayed session.ended would re-close a session and re-run billing.
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    const old = NOW - 10 * 60_000;
    expect(adapter.verifyWebhookSignature(body, header(old, sign(body)))).toBe(false);
  });

  it('accepts a webhook just inside the tolerance window', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch, {
      webhookToleranceMs: 300_000,
    });
    expect(adapter.verifyWebhookSignature(body, header(NOW - 299_000, sign(body)))).toBe(true);
  });

  it('rejects a future-dated timestamp beyond tolerance', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    expect(adapter.verifyWebhookSignature(body, header(NOW + 10 * 60_000, sign(body)))).toBe(false);
  });

  it('rejects malformed, empty and missing headers', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    expect(adapter.verifyWebhookSignature(body, null)).toBe(false);
    expect(adapter.verifyWebhookSignature(body, '')).toBe(false);
    expect(adapter.verifyWebhookSignature(body, 'garbage')).toBe(false);
    expect(adapter.verifyWebhookSignature(body, `v1=${sign(body)}`)).toBe(false); // no timestamp
    expect(adapter.verifyWebhookSignature(body, `t=${NOW}`)).toBe(false); // no digest
  });

  it('fails closed when no webhook secret is configured', () => {
    const adapter = new EdrvAdapter({ apiKey: API_KEY, energyUnit: 'Wh' });
    expect(adapter.verifyWebhookSignature(body, header(NOW, sign(body)))).toBe(false);
  });

  it('rejects a body altered after signing', () => {
    const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);
    const signature = header(NOW, sign(body));
    const tampered = JSON.stringify({ event: 'session.ended', data: { _id: 'OTHER' } });
    expect(adapter.verifyWebhookSignature(tampered, signature)).toBe(false);
  });
});

describe('EdrvAdapter — webhook parsing', () => {
  const adapter = makeAdapter(vi.fn() as unknown as typeof fetch);

  it.each([
    ['session.started', 'charging_started'],
    ['session.ended', 'charging_stopped'],
    ['session.start_failure', 'charging_failed'],
    ['session.stop_failure', 'charging_failed'],
    ['session.cancelled', 'charging_failed'],
    ['session.updated', 'meter_values'],
    ['session.ev_charged', 'meter_values'],
    ['chargestation.online', 'connector_online'],
    ['chargestation.offline', 'connector_offline'],
  ])('maps %s -> %s', (event, expected) => {
    const parsed = adapter.parseWebhookEvent({
      _id: 'evt_1',
      event,
      created: '2026-08-08T10:00:00Z',
      data: { _id: 's1' },
    });
    expect(parsed?.type).toBe(expected);
  });

  it('resolves connector_status.updated by the reported status', () => {
    const faulted = adapter.parseWebhookEvent({
      _id: 'e1',
      event: 'chargestation.connector_status.updated',
      data: { _id: 'c1', status: 'Faulted' },
    });
    expect(faulted?.type).toBe('fault_detected');

    const available = adapter.parseWebhookEvent({
      _id: 'e2',
      event: 'chargestation.connector_status.updated',
      data: { _id: 'c1', status: 'Available' },
    });
    expect(available?.type).toBe('connector_online');

    const unavailable = adapter.parseWebhookEvent({
      _id: 'e3',
      event: 'chargestation.connector_status.updated',
      data: { _id: 'c1', status: 'Unavailable' },
    });
    expect(unavailable?.type).toBe('connector_offline');
  });

  it('converts energy in the meter value it extracts', () => {
    const parsed = adapter.parseWebhookEvent({
      _id: 'e1',
      event: 'session.ev_charged',
      created: '2026-08-08T10:00:00Z',
      data: { _id: 's1', energy: 12800, power: 55000 },
    });
    expect(parsed?.meterValue?.energyKwh).toBe(12.8);
    expect(parsed?.meterValue?.powerKw).toBe(55);
  });

  it('reads a reference whether it is a bare id or an expanded object', () => {
    const bare = adapter.parseWebhookEvent({
      _id: 'e1',
      event: 'session.started',
      data: { _id: 's1', connector: 'conn_1' },
    });
    expect(bare?.providerConnectorId).toBe('conn_1');

    const expanded = adapter.parseWebhookEvent({
      _id: 'e2',
      event: 'session.started',
      data: { _id: 's1', connector: { _id: 'conn_2' } },
    });
    expect(expanded?.providerConnectorId).toBe('conn_2');
  });

  it('returns null for unknown events and malformed payloads', () => {
    expect(adapter.parseWebhookEvent({ _id: 'e', event: 'rate.created' })).toBeNull();
    expect(adapter.parseWebhookEvent({ data: {} })).toBeNull();
    expect(adapter.parseWebhookEvent(null)).toBeNull();
    expect(adapter.parseWebhookEvent('not an object')).toBeNull();
    expect(adapter.parseWebhookEvent(42)).toBeNull();
  });
});
