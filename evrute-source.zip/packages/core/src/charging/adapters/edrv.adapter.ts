/**
 * eDRV adapter (API v1.1).
 *
 * The second implementation of `ChargingProvider`, and the one that proves
 * the abstraction was worth having: eDRV differs from ChargeLab in almost
 * every surface detail — response envelope, stop verb, signature scheme,
 * event names, energy units — and none of that leaks past this file.
 *
 * Verified against https://docs.edrv.io (v1.1) rather than assumed:
 *   auth      Authorization: Bearer <API_KEY>
 *   start     POST /v1.1/sessions  { connector, user }
 *   stop      GET  /v1.1/sessions/{id}/stop        <- GET, not POST
 *   envelope  { result: … } on success
 *   webhooks  header `edrv-signature: t=<ms>,v1=<hex>`, HMAC-SHA256
 *
 * TWO THINGS THAT WILL BITE IF YOU CHANGE THIS FILE
 *
 * 1. `energyUnit`. eDRV reports metered energy in Wh in most deployments,
 *    but the docs do not state it unambiguously and it is configurable per
 *    account. Getting it wrong is a 1000x billing error in one direction or
 *    the other. So it is an explicit config value with no silent default
 *    guess — see `EdrvConfig.energyUnit` — and it MUST be confirmed against
 *    one real session before this adapter bills anybody.
 *
 * 2. `user`. eDRV requires one of ITS user ids on every session start. That
 *    is not our `profiles.id`. The mapping lives in
 *    `profiles.provider_user_ref` and arrives here via
 *    `SessionContext.providerUserRef`. Starting a session without it is an
 *    error we raise loudly rather than papering over.
 */

import { createHmac, timingSafeEqual } from 'node:crypto';
import {
  ChargingProviderError,
  type ChargingProvider,
  type ConnectorLiveStatus,
  type DateRange,
  type FaultStatus,
  type FirmwareStatus,
  type MeterValue,
  type ProviderCharger,
  type ProviderConnector,
  type ProviderPricing,
  type ProviderReservationRef,
  type ProviderSessionDetails,
  type ProviderSessionRef,
  type ProviderStation,
  type ProviderWebhookEvent,
  type ProviderWebhookEventType,
  type ReservationWindow,
  type SessionContext,
} from '../provider';

export interface EdrvConfig {
  readonly apiKey: string;
  readonly webhookSecret?: string;
  readonly baseUrl?: string;
  /**
   * Unit eDRV reports metered energy in. NOT optional and NOT guessed —
   * see the note at the top of this file. Confirm against a real session
   * before billing.
   */
  readonly energyUnit: 'Wh' | 'kWh';
  /** Reject webhooks older than this. Docs suggest 3–5 minutes. */
  readonly webhookToleranceMs?: number;
  readonly fetchImpl?: typeof fetch;
}

const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);

/**
 * eDRV surfaces OCPP 1.6 StatusNotification values. Anything unrecognised
 * maps to 'offline' rather than 'available': treating an unknown state as
 * free would send a driver to a charger that cannot serve them.
 */
const CONNECTOR_STATUS: Record<string, ConnectorLiveStatus> = {
  Available: 'available',
  Preparing: 'occupied',
  Charging: 'occupied',
  SuspendedEV: 'occupied',
  SuspendedEVSE: 'occupied',
  Finishing: 'occupied',
  Reserved: 'reserved',
  Unavailable: 'offline',
  Faulted: 'faulted',
};

const EVENT_MAP: Record<string, ProviderWebhookEventType> = {
  'session.started': 'charging_started',
  'session.ended': 'charging_stopped',
  'session.start_failure': 'charging_failed',
  'session.stop_failure': 'charging_failed',
  'session.cancelled': 'charging_failed',
  'session.updated': 'meter_values',
  'session.ev_charged': 'meter_values',
  'chargestation.online': 'connector_online',
  'chargestation.offline': 'connector_offline',
  'chargestation.connector_status.updated': 'connector_online',
};

export class EdrvAdapter implements ChargingProvider {
  readonly name = 'edrv';
  readonly #baseUrl: string;
  readonly #fetch: typeof fetch;
  readonly #toleranceMs: number;

  constructor(private readonly config: EdrvConfig) {
    if (!config.apiKey) throw new Error('EdrvAdapter requires an apiKey');
    if (config.energyUnit !== 'Wh' && config.energyUnit !== 'kWh') {
      throw new Error(
        "EdrvAdapter requires energyUnit to be 'Wh' or 'kWh'. It is not guessed: " +
          'getting it wrong is a 1000x billing error.',
      );
    }
    this.#baseUrl = (config.baseUrl ?? 'https://api.edrv.io/v1.1').replace(/\/$/, '');
    this.#fetch = config.fetchImpl ?? fetch;
    this.#toleranceMs = config.webhookToleranceMs ?? 5 * 60_000;
  }

  /** Wh -> kWh at the single boundary where it can be got wrong once. */
  #toKwh(value: number | null | undefined): number {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < 0) return 0;
    return this.config.energyUnit === 'Wh' ? value / 1000 : value;
  }

  async #request<T>(operation: string, path: string, init: RequestInit = {}): Promise<T> {
    let response: Response;
    try {
      response = await this.#fetch(`${this.#baseUrl}${path}`, {
        ...init,
        headers: {
          authorization: `Bearer ${this.config.apiKey}`,
          accept: 'application/json',
          'content-type': 'application/json',
          ...init.headers,
        },
      });
    } catch (cause) {
      throw new ChargingProviderError(`network error calling ${operation}`, {
        provider: this.name,
        operation,
        retryable: true,
        cause,
      });
    }

    const text = await response.text().catch(() => '');

    if (!response.ok) {
      throw new ChargingProviderError(
        `${operation} failed with ${response.status}: ${text.slice(0, 300)}`,
        {
          provider: this.name,
          operation,
          status: response.status,
          retryable: RETRYABLE_STATUS.has(response.status),
        },
      );
    }

    if (!text.trim()) return undefined as T;

    let parsed: unknown;
    try {
      parsed = JSON.parse(text);
    } catch (cause) {
      throw new ChargingProviderError(`${operation} returned malformed JSON`, {
        provider: this.name,
        operation,
        retryable: false,
        cause,
      });
    }

    // eDRV wraps successful payloads in { result: … }. Unwrap here so no
    // caller has to know that.
    const envelope = parsed as { result?: unknown };
    return (envelope && typeof envelope === 'object' && 'result' in envelope
      ? envelope.result
      : parsed) as T;
  }

  async listStations(): Promise<ProviderStation[]> {
    const data = await this.#request<RawLocation[]>('listStations', '/locations');
    return (data ?? []).map((l) => ({
      id: l._id,
      name: l.name ?? l._id,
      latitude: l.coordinates?.latitude ?? l.address?.latitude ?? null,
      longitude: l.coordinates?.longitude ?? l.address?.longitude ?? null,
      address: [l.address?.street, l.address?.city].filter(Boolean).join(', ') || null,
    }));
  }

  async listChargers(stationId: string): Promise<ProviderCharger[]> {
    const data = await this.#request<RawChargestation[]>(
      'listChargers',
      `/chargestations?location=${encodeURIComponent(stationId)}`,
    );
    return (data ?? []).map((c) => ({
      id: c._id,
      stationId,
      label: c.name ?? c.identity ?? c._id,
      vendor: c.vendor ?? null,
      model: c.model ?? null,
      powerKw: c.max_power ? this.#toKwh(c.max_power) : 0,
      ocppVersion: c.ocpp_version === '2.0.1' ? '2.0.1' : '1.6J',
      firmwareVersion: c.firmware_version ?? null,
      online: c.online === true,
    }));
  }

  async listConnectors(chargerId: string): Promise<ProviderConnector[]> {
    const charger = await this.#request<RawChargestation>(
      'listConnectors',
      `/chargestations/${encodeURIComponent(chargerId)}`,
    );
    return (charger?.connectors ?? []).map((c) => ({
      id: c._id,
      chargerId,
      connectorNumber: c.connector_id ?? 1,
      type: c.type ?? 'UNKNOWN',
      currentType: c.current_type === 'AC' ? 'AC' : 'DC',
      powerKw: c.max_power ? this.#toKwh(c.max_power) : 0,
      status: CONNECTOR_STATUS[c.status ?? ''] ?? 'offline',
    }));
  }

  async getConnectorStatus(connectorId: string): Promise<ConnectorLiveStatus> {
    const data = await this.#request<RawConnector>(
      'getConnectorStatus',
      `/connectors/${encodeURIComponent(connectorId)}`,
    );
    return CONNECTOR_STATUS[data?.status ?? ''] ?? 'offline';
  }

  async startCharging(connectorId: string, ctx: SessionContext): Promise<ProviderSessionRef> {
    // eDRV keys sessions to ITS user, not ours. Without the mapping the
    // request would 400 with something opaque; fail here with a message
    // that names the actual problem.
    const user = ctx.providerUserRef;
    if (!user) {
      throw new ChargingProviderError(
        `no eDRV user id for EVRute user ${ctx.userId}. Create the eDRV user and ` +
          'store its id in profiles.provider_user_ref before starting a session.',
        { provider: this.name, operation: 'startCharging', retryable: false },
      );
    }

    const body: Record<string, unknown> = { connector: connectorId, user };
    if (ctx.energyLimitKwh !== undefined) {
      body['target'] = {
        power: this.config.energyUnit === 'Wh' ? ctx.energyLimitKwh * 1000 : ctx.energyLimitKwh,
      };
    }
    // Round-trips our session id so a webhook can be correlated even if the
    // provider ref is lost in transit.
    body['meta_data'] = { evrute_session_id: ctx.sessionId };

    const session = await this.#request<RawSession>('startCharging', '/sessions', {
      method: 'POST',
      body: JSON.stringify(body),
    });

    if (!session?._id) {
      throw new ChargingProviderError('eDRV accepted the start but returned no session id', {
        provider: this.name,
        operation: 'startCharging',
        retryable: false,
      });
    }

    return {
      providerSessionId: session._id,
      ...(session.start_date ? { startedAt: session.start_date } : {}),
    };
  }

  async stopCharging(ref: ProviderSessionRef): Promise<void> {
    // Yes, GET. eDRV models stop as a GET with a side effect. Documented
    // here so nobody "fixes" it to POST and silently breaks every stop.
    await this.#request<void>(
      'stopCharging',
      `/sessions/${encodeURIComponent(ref.providerSessionId)}/stop`,
      { method: 'GET' },
    );
  }

  async reserveConnector(
    _connectorId: string,
    _window: ReservationWindow,
  ): Promise<ProviderReservationRef> {
    // eDRV v1.1 exposes no reservation endpoint. Throwing beats returning a
    // fake reference that would let the app show a reservation the charger
    // knows nothing about.
    throw new ChargingProviderError('eDRV v1.1 does not support reservations', {
      provider: this.name,
      operation: 'reserveConnector',
      retryable: false,
    });
  }

  async cancelReservation(_ref: ProviderReservationRef): Promise<void> {
    throw new ChargingProviderError('eDRV v1.1 does not support reservations', {
      provider: this.name,
      operation: 'cancelReservation',
      retryable: false,
    });
  }

  async getSessionDetails(ref: ProviderSessionRef): Promise<ProviderSessionDetails> {
    const s = await this.#request<RawSession>(
      'getSessionDetails',
      `/sessions/${encodeURIComponent(ref.providerSessionId)}`,
    );
    return this.#toSessionDetails(s);
  }

  async getMeterValues(ref: ProviderSessionRef): Promise<MeterValue[]> {
    const reports = await this.#request<RawEnergyReport[]>(
      'getMeterValues',
      `/sessions/${encodeURIComponent(ref.providerSessionId)}/energy_reports`,
    );
    return (reports ?? []).map((r) => ({
      recordedAt: r.timestamp ?? new Date().toISOString(),
      energyKwh: this.#toKwh(r.energy ?? r.total_energy),
      ...(r.power !== undefined ? { powerKw: this.#toKwh(r.power) } : {}),
      ...(r.soc !== undefined ? { socPct: r.soc } : {}),
    }));
  }

  async getChargingHistory(
    connectorId: string,
    range: DateRange,
  ): Promise<ProviderSessionDetails[]> {
    const params = new URLSearchParams({
      connector: connectorId,
      from: range.from.toISOString(),
      to: range.to.toISOString(),
    });
    const data = await this.#request<RawSession[]>(
      'getChargingHistory',
      `/sessions?${params.toString()}`,
    );
    return (data ?? []).map((s) => this.#toSessionDetails(s));
  }

  async getFirmwareStatus(chargerId: string): Promise<FirmwareStatus> {
    const c = await this.#request<RawChargestation>(
      'getFirmwareStatus',
      `/chargestations/${encodeURIComponent(chargerId)}`,
    );
    return {
      chargerId,
      version: c?.firmware_version ?? null,
      updateAvailable: false, // eDRV exposes no "update available" flag.
    };
  }

  async getFaultStatus(chargerId: string): Promise<FaultStatus> {
    const c = await this.#request<RawChargestation>(
      'getFaultStatus',
      `/chargestations/${encodeURIComponent(chargerId)}`,
    );
    const faulted = (c?.connectors ?? []).some((x) => x.status === 'Faulted');
    return {
      chargerId,
      faulted,
      errorCode: (c?.connectors ?? []).find((x) => x.error_code)?.error_code ?? null,
      message: null,
    };
  }

  async getPricing(): Promise<ProviderPricing> {
    // Tariffs are EVRute's. eDRV rates exist but are not what we bill on.
    return { pricePerKwh: null, sessionFee: null, currency: 'INR' };
  }

  /**
   * `edrv-signature: t=<ms>,v1=<hex>` — HMAC-SHA256 of the raw JSON body.
   *
   * The timestamp is checked as well as the digest. A valid signature is
   * replayable forever without it, and a replayed `session.ended` would
   * re-close a session and re-run its billing path.
   */
  verifyWebhookSignature(rawBody: string, signature: string | null): boolean {
    if (!signature || !this.config.webhookSecret) return false;

    let timestamp: number | null = null;
    let provided: string | null = null;
    for (const part of signature.split(',')) {
      const [key, value] = part.trim().split('=');
      if (key === 't' && value) timestamp = Number(value);
      if (key === 'v1' && value) provided = value;
    }
    if (!provided || timestamp === null || !Number.isFinite(timestamp)) return false;

    const age = Math.abs(Date.now() - timestamp);
    if (age > this.#toleranceMs) return false;

    const expected = createHmac('sha256', this.config.webhookSecret)
      .update(rawBody, 'utf8')
      .digest('hex');

    if (provided.length !== expected.length) return false;
    try {
      return timingSafeEqual(Buffer.from(expected, 'hex'), Buffer.from(provided, 'hex'));
    } catch {
      return false;
    }
  }

  parseWebhookEvent(payload: unknown): ProviderWebhookEvent | null {
    if (typeof payload !== 'object' || payload === null) return null;
    const body = payload as RawWebhook;

    const name = body.event ?? body.type;
    if (!name) return null;

    const data = body.data ?? body.object ?? {};

    // connector_status.updated carries the actual state; resolve it to the
    // right internal event instead of always reporting "online".
    let type = EVENT_MAP[name];
    if (name === 'chargestation.connector_status.updated') {
      const status = CONNECTOR_STATUS[data.status ?? ''] ?? 'offline';
      type =
        status === 'faulted'
          ? 'fault_detected'
          : status === 'offline'
            ? 'connector_offline'
            : 'connector_online';
    }
    if (!type) return null;

    const eventId = body._id ?? body.id ?? `${name}:${data._id ?? ''}:${body.created ?? ''}`;
    if (!eventId.trim()) return null;

    const energy = data.energy ?? data.total_energy;

    return {
      eventId,
      type,
      occurredAt: body.created ?? new Date().toISOString(),
      ...(data._id && name.startsWith('session') ? { providerSessionId: data._id } : {}),
      ...spreadIf('providerConnectorId', readId(data.connector)),
      ...spreadIf('providerChargerId', readId(data.chargestation)),
      ...(energy !== undefined
        ? {
            meterValue: {
              recordedAt: body.created ?? new Date().toISOString(),
              energyKwh: this.#toKwh(energy),
              ...(data.power !== undefined ? { powerKw: this.#toKwh(data.power) } : {}),
              ...(data.soc !== undefined ? { socPct: data.soc } : {}),
            },
          }
        : {}),
      ...(data.error_code ? { errorCode: data.error_code } : {}),
      ...(data.message ? { message: data.message } : {}),
    };
  }

  #toSessionDetails(s: RawSession | null | undefined): ProviderSessionDetails {
    const status = s?.status ?? s?.state ?? '';
    return {
      providerSessionId: s?._id ?? '',
      status:
        status === 'ended' || status === 'completed'
          ? 'completed'
          : status === 'cancelled' || status === 'failed'
            ? 'failed'
            : s?.start_date
              ? 'active'
              : 'pending',
      startedAt: s?.start_date ?? null,
      stoppedAt: s?.end_date ?? null,
      energyKwh: this.#toKwh(s?.energy ?? s?.total_energy),
      ...(s?.stop_reason ? { stopReason: s.stop_reason } : {}),
    };
  }
}

/**
 * Omit a key entirely when its value is undefined. `exactOptionalPropertyTypes`
 * distinguishes "absent" from "present and undefined", and the interface means
 * the former.
 */
function spreadIf<K extends string>(key: K, value: string | undefined): Record<K, string> | Record<string, never> {
  return value === undefined ? {} : ({ [key]: value } as Record<K, string>);
}

/** eDRV returns references either as a bare id or as an expanded object. */
function readId(value: string | { _id?: string } | undefined): string | undefined {
  if (typeof value === 'string') return value;
  return value?._id;
}

// -- Wire shapes. Deliberately loose: a new upstream field must never crash
// -- a webhook handler, and every value is normalised on the way out.
interface RawLocation {
  _id: string;
  name?: string;
  coordinates?: { latitude?: number; longitude?: number };
  address?: { street?: string; city?: string; latitude?: number; longitude?: number };
}
interface RawConnector {
  _id: string;
  connector_id?: number;
  type?: string;
  current_type?: string;
  max_power?: number;
  status?: string;
  error_code?: string;
}
interface RawChargestation {
  _id: string;
  name?: string;
  identity?: string;
  vendor?: string;
  model?: string;
  max_power?: number;
  ocpp_version?: string;
  firmware_version?: string;
  online?: boolean;
  connectors?: RawConnector[];
}
interface RawSession {
  _id: string;
  status?: string;
  state?: string;
  start_date?: string;
  end_date?: string;
  energy?: number;
  total_energy?: number;
  stop_reason?: string;
}
interface RawEnergyReport {
  timestamp?: string;
  energy?: number;
  total_energy?: number;
  power?: number;
  soc?: number;
}
interface RawWebhook {
  _id?: string;
  id?: string;
  event?: string;
  type?: string;
  created?: string;
  data?: RawEventData;
  object?: RawEventData;
}
interface RawEventData {
  _id?: string;
  status?: string;
  energy?: number;
  total_energy?: number;
  power?: number;
  soc?: number;
  error_code?: string;
  message?: string;
  connector?: string | { _id?: string };
  chargestation?: string | { _id?: string };
}
