import 'server-only';

import { RazorpayAdapter, type PaymentProvider } from '@evrute/core/server';
import { isProduction, serverEnv } from '@/lib/env';

/**
 * Composition root for the payment provider on the server.
 *
 * Unlike charging there is no dev/test simulator here — money code paths
 * are exercised against the real Razorpay test-mode API instead, so a
 * missing credential is always an error, in every environment.
 */

let cached: PaymentProvider | null = null;

export function getPaymentProvider(): PaymentProvider {
  if (cached) return cached;

  const env = serverEnv();

  if (env.PAYMENT_PROVIDER === 'cashfree') {
    throw new Error(
      'Cashfree adapter is not implemented yet. Implement PaymentProvider in ' +
        'a cashfree adapter and register it in lib/server/payments.ts.',
    );
  }

  const { RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, RAZORPAY_WEBHOOK_SECRET } = env;
  if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET || !RAZORPAY_WEBHOOK_SECRET) {
    throw new Error(
      isProduction
        ? 'RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET and RAZORPAY_WEBHOOK_SECRET must be ' +
          'configured in production.'
        : 'Razorpay credentials are not configured. Set RAZORPAY_KEY_ID, ' +
          'RAZORPAY_KEY_SECRET and RAZORPAY_WEBHOOK_SECRET.',
    );
  }

  cached = new RazorpayAdapter({
    keyId: RAZORPAY_KEY_ID,
    keySecret: RAZORPAY_KEY_SECRET,
    webhookSecret: RAZORPAY_WEBHOOK_SECRET,
  });
  return cached;
}
