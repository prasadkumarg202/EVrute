import 'server-only';

import {
  createChargingProviderService,
  type ChargingProviderService,
} from '@evrute/core/server';
import { isProduction, serverEnv } from '@/lib/env';

/**
 * Composition root for the charging provider on the server.
 *
 * Memoised per server instance (module-level singleton) so every route
 * handler and webhook reuses one circuit breaker instead of each request
 * building its own — the breaker's whole point is to remember failures
 * across calls.
 *
 * `CHARGING_PROVIDER=simulator` in dev/CI, `chargelab` or `edrv` in
 * production. A production deploy missing credentials fails loudly here
 * rather than silently falling back to the simulator and reporting phantom
 * charging sessions.
 */

let cached: ChargingProviderService | null = null;

export function getChargingProvider(): ChargingProviderService {
  if (cached) return cached;

  const env = serverEnv();

  if (isProduction && env.CHARGING_PROVIDER === 'simulator') {
    throw new Error(
      'CHARGING_PROVIDER=simulator is not permitted in production. ' +
        'Set CHARGING_PROVIDER=chargelab or edrv and the matching credentials.',
    );
  }

  if (env.CHARGING_PROVIDER === 'chargelab') {
    const { CHARGING_PROVIDER_BASE_URL, CHARGING_PROVIDER_API_KEY, CHARGING_PROVIDER_WEBHOOK_SECRET } = env;
    if (!CHARGING_PROVIDER_BASE_URL || !CHARGING_PROVIDER_API_KEY || !CHARGING_PROVIDER_WEBHOOK_SECRET) {
      throw new Error(
        'CHARGING_PROVIDER=chargelab requires CHARGING_PROVIDER_BASE_URL, ' +
          'CHARGING_PROVIDER_API_KEY and CHARGING_PROVIDER_WEBHOOK_SECRET to be set.',
      );
    }
    cached = createChargingProviderService({
      kind: 'chargelab',
      chargelab: {
        baseUrl: CHARGING_PROVIDER_BASE_URL,
        apiKey: CHARGING_PROVIDER_API_KEY,
        webhookSecret: CHARGING_PROVIDER_WEBHOOK_SECRET,
      },
    });
    return cached;
  }

  if (env.CHARGING_PROVIDER === 'edrv') {
    const {
      CHARGING_PROVIDER_API_KEY,
      CHARGING_PROVIDER_WEBHOOK_SECRET,
      CHARGING_PROVIDER_BASE_URL,
      EDRV_ENERGY_UNIT,
      EDRV_WEBHOOK_TOLERANCE_MS,
    } = env;

    if (!CHARGING_PROVIDER_API_KEY) {
      throw new Error('CHARGING_PROVIDER=edrv requires CHARGING_PROVIDER_API_KEY.');
    }

    // No default. eDRV reports energy in Wh in most deployments but it is
    // account-configurable, and picking wrong misbills every session by
    // 1000x. Refusing to boot is the correct failure here.
    if (!EDRV_ENERGY_UNIT) {
      throw new Error(
        'CHARGING_PROVIDER=edrv requires EDRV_ENERGY_UNIT to be "Wh" or "kWh". ' +
          'It has no default on purpose: confirm it against one real session ' +
          '(compare the energy on the eDRV dashboard with the raw API value) ' +
          'before billing anyone. Guessing wrong is a 1000x billing error.',
      );
    }

    if (!CHARGING_PROVIDER_WEBHOOK_SECRET) {
      // Not fatal: outbound calls work. But webhook-driven session state —
      // started, metered, ended — will all be rejected as unverifiable.
      console.warn(
        'CHARGING_PROVIDER_WEBHOOK_SECRET is not set. eDRV webhooks cannot be ' +
          'verified and will be rejected, so sessions will never leave "pending".',
      );
    }

    cached = createChargingProviderService({
      kind: 'edrv',
      edrv: {
        apiKey: CHARGING_PROVIDER_API_KEY,
        energyUnit: EDRV_ENERGY_UNIT,
        webhookToleranceMs: EDRV_WEBHOOK_TOLERANCE_MS,
        ...(CHARGING_PROVIDER_BASE_URL ? { baseUrl: CHARGING_PROVIDER_BASE_URL } : {}),
        ...(CHARGING_PROVIDER_WEBHOOK_SECRET
          ? { webhookSecret: CHARGING_PROVIDER_WEBHOOK_SECRET }
          : {}),
      },
    });
    return cached;
  }

  cached = createChargingProviderService({ kind: env.CHARGING_PROVIDER });
  return cached;
}
