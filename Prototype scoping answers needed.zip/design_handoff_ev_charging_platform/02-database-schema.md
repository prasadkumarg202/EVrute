# 02 — PostgreSQL Schema

Core tables (add indexes on all foreign keys and on `status`/`created_at` columns used for filtering):

## users
| column | type | notes |
|---|---|---|
| id | uuid PK | |
| phone | varchar unique | +91 format |
| email | varchar nullable | |
| name | varchar | |
| role | enum(customer, owner, admin, employee) | |
| auth_provider | enum(otp, google, apple) | |
| wallet_id | uuid FK → wallets.id | |
| created_at / updated_at | timestamptz | |

## vehicles
id, user_id FK, make, model, plate_number, connector_type enum(CCS2, Type2, GB/T, CHAdeMO), battery_capacity_kwh, created_at

## stations
id, owner_id FK → users.id, name, address, lat, lng, city, state, amenities jsonb, rating_avg numeric, status enum(active, maintenance, under_review, suspended), created_at

## chargers
id, station_id FK, provider_charger_id varchar (id on ChargeLab/eDRV side), model, power_kw, ocpp_version enum(1.6J, 2.0.1), firmware_version, status enum(online, offline, faulted), created_at

## connectors
id, charger_id FK, provider_connector_id varchar, type enum(CCS2, Type2, GB/T, CHAdeMO, AC, DC), power_kw, status enum(available, in_use, offline, reserved), created_at

## sessions
id, user_id FK, vehicle_id FK, connector_id FK, provider_session_ref varchar, started_at, stopped_at, energy_kwh numeric, duration_seconds int, cost numeric, status enum(pending, active, completed, failed), created_at

## wallet
id, user_id FK, balance numeric default 0, currency char(3) default 'INR', updated_at

## payments
id, user_id FK, provider enum(razorpay, cashfree), provider_order_id, provider_payment_id, amount numeric, status enum(created, captured, failed, refunded), purpose enum(wallet_recharge, session_topup), created_at

## transactions
id, wallet_id FK, session_id FK nullable, type enum(credit, debit), amount numeric, balance_after numeric, reference varchar, created_at

## settlements
id, owner_id FK, period_start, period_end, gross_amount numeric, commission_amount numeric, gst_amount numeric, tds_amount numeric, net_amount numeric, status enum(pending, processing, paid), payout_reference varchar, paid_at, created_at

## pricing
id, station_id FK, connector_type enum, price_per_kwh numeric, session_fee numeric, effective_from, created_at

## favorites
id, user_id FK, station_id FK, created_at (unique on user_id+station_id)

## reviews
id, user_id FK, station_id FK, rating smallint (1-5), comment text, created_at

## notifications
id, user_id FK, type varchar, title, body, read_at nullable, created_at

## tickets
id, user_id FK, subject, description, status enum(open, in_progress, resolved, closed), priority enum(low, medium, high), created_at

## coupons
id, code varchar unique, discount_type enum(flat, percent), value numeric, max_uses int, used_count int default 0, valid_from, valid_to, created_at

## analytics
Materialized/rollup tables, not raw event storage: `daily_station_stats` (station_id, date, sessions_count, energy_kwh, revenue), `daily_platform_stats` (date, active_users, active_sessions, revenue). Populate via scheduled jobs (BullMQ + Redis), not synchronous request paths.
