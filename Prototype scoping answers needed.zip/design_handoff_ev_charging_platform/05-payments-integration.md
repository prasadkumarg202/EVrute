# 05 — Payments, Wallet & Settlement

## Merchant account setup
### Razorpay
1. Create a Razorpay business account (razorpay.com) → complete KYC (PAN, GST, bank account).
2. Generate API keys (Test mode first) from Dashboard → Settings → API Keys.
3. Enable required payment methods: UPI, cards, netbanking, wallets.
4. Set up a webhook (Dashboard → Webhooks) pointing to `payments.controller`'s Razorpay handler, subscribed to `payment.captured`, `payment.failed`, `refund.processed`.
5. Store `RAZORPAY_KEY_ID`/`RAZORPAY_KEY_SECRET`/`RAZORPAY_WEBHOOK_SECRET` in Secrets Manager.

### Cashfree (secondary/alternate PSP)
1. Create a Cashfree merchant account (cashfree.com) → KYC.
2. Generate App ID + Secret Key from the dashboard (Test then Production).
3. Configure webhook for payment status callbacks.
4. Store credentials the same way as Razorpay.

Route selection (Razorpay vs Cashfree) can be a simple config flag per region/owner, or an A/B split — keep both behind a `PaymentProvider` interface analogous to `ChargingProvider`, so the payments module isn't hard-wired to one PSP.

## Wallet flow
```
Customer taps "Add Money" → POST /wallet/recharge {amount}
  → payments.service creates a Razorpay/Cashfree order
  → Flutter app opens the PSP checkout SDK
  → PSP redirects/webhooks payment.captured
  → payments webhook handler verifies signature → credits wallet (transactions row, type=credit)
  → push notification confirms new balance
```
All wallet balance mutations go through the `transactions` ledger table (never mutate `wallet.balance` directly outside a transaction insert) so balance is always reconstructable/auditable.

## Charging session payment
1. On `POST /session/start`, place a soft hold (reserve) equal to an estimated minimum cost against wallet balance — reject start if insufficient.
2. On session stop / `Charging Stopped` webhook, compute final cost from metered `energy_kwh` × station pricing + session fee, debit wallet (transaction row, type=debit, linked to `session_id`), release any unused hold.
3. Generate invoice (PDF, platform-branded, not provider-branded) and store reference on the session; expose via `GET /invoice`.

## Settlement engine
Runs as a scheduled job (daily/weekly/monthly per owner contract terms):
1. Aggregate all `completed` sessions for the owner's stations in the period → gross_amount
2. Apply platform commission % (owner contract term), GST, TDS per statutory rules
3. Insert a `settlements` row: gross, commission, gst, tds, net, status=pending
4. Batch approved settlements → initiate bank transfer (via Razorpay Route/Cashfree Payouts, or your bank's payout API) → status=processing → on payout confirmation, status=paid, store payout_reference
5. Owner portal's Settlements screen and Admin's Settlement queue (see prototype) both read this table — owner sees only their rows, admin sees all with a process/approve action

## Security & compliance
- Never store raw card data — PSP checkout SDKs handle PCI scope
- Verify every payment/payout webhook signature before mutating financial state
- Idempotency keys on recharge, session debit, and settlement payout initiation
- Reconciliation job: nightly compare PSP settlement reports against local `payments`/`settlements` tables, alert on mismatch
