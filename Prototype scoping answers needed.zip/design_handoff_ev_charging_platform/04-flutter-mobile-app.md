# 04 — Flutter Mobile App (Customer)

Build the customer-facing mobile app in Flutter (Android + iOS), using `reference/EV Charging Platform Prototype.dc.html` (Customer app surface) as the UX source. Apply your product's own visual design system for colors/type — the prototype's tap2news-derived palette is a placeholder only.

## Screen map (prototype → Flutter screen)
| Prototype screen | Flutter screen | Key state | Backend calls |
|---|---|---|---|
| Login | `LoginScreen` | phone number, OTP step, social login | `POST /auth/login` |
| Map & search | `StationMapScreen` | user location, connector-type filter, station list (bottom sheet) | `GET /stations` (lat/lng/radius/filter) |
| Station details | `StationDetailScreen` | selected station, connector list, live status | `GET /station/{id}`, `GET /connector/{id}` |
| Live charging session | `ChargingSessionScreen` | elapsed time, kWh delivered, live cost, session status | `POST /session/start`, poll/subscribe session status, `POST /session/stop` |
| Wallet | `WalletScreen` | balance, add-money sheet, payment method picker | `GET /wallet`, `POST /wallet/recharge` |
| Invoice/history | `HistoryScreen` | past sessions list, invoice download | `GET /history`, `GET /invoice` |
| Vehicle profile | `VehicleScreen` | vehicle(s), battery %, add vehicle | `GET /vehicle` |
| Referral/rewards | `ReferralScreen` | referral code, invite stats, carbon saved | platform-specific endpoint (add to spec) |

## Navigation
Bottom tab bar: Map, Wallet, History, Vehicle, Referral (5 tabs, always visible except during Login/Station-details/Charging-session, which are pushed as full-screen routes with a back action — matches the prototype's `showTabBar` logic).

## Flow to implement end-to-end first (per user priority)
Map → Station details → Reserve (optional) → Start charging → live session → Stop → invoice generated → wallet debited. This is the flow validated in the prototype (`startCharging`/`stopCharging` handlers) — replicate the same state transitions against the real `/session/start` and `/session/stop` endpoints and provider webhooks (session status should update from webhook-driven push, not just client polling — use Firebase Cloud Messaging or a WebSocket/SSE channel from your backend for live session + connector status).

## State management
Use your team's standard (Riverpod/Bloc/Provider). Minimum state slices: `AuthState`, `WalletState`, `ActiveSessionState` (must survive app backgrounding — persist session id and reconcile on resume), `StationSearchState`, `VehicleState`.

## Design tokens to define (Flutter theme)
Mirror the token categories used in the prototype (not its values): brand/primary color, neutral/ink ramp for text, surface/background, semantic success/warning/danger for connector + settlement statuses, a display font for headings/data (tabular figures for kWh/₹ values) and a body font. Confirm actual hex/type choices with whoever owns the product's visual identity before implementation.

## Non-negotiable UX details from the prototype
- Connector status always shown with color + label (not color alone): available/in-use/offline
- Every price shown as ₹/kWh plus a flat session fee, both visible before start
- Stop-charging always reachable with one tap from the live session screen
- Wallet balance visible before a charging session starts; block start if balance is insufficient (add this guard — not shown in the prototype but required by the payment flow)
