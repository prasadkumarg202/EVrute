# 06 — Owner Portal & Admin Panel (React 19 + NextJS)

Build these as two role-gated web apps (or one app with route-based role guards) per the original spec's stack: React 19 + NextJS, calling the same NestJS backend as the Flutter app. Use `reference/EV Charging Platform Prototype.dc.html` (Owner portal / Admin panel surfaces) as the UX source — same fidelity note as `04`: structure and flow are the reference, not the placeholder color palette.

## Owner Portal — screen map
| Prototype screen | Purpose | Backend calls |
|---|---|---|
| Dashboard | Active sessions, today's revenue, total chargers, uptime %, 7-day charging activity chart, recent sessions | `GET /owner/dashboard` (aggregate), `GET /owner/sessions?limit=` |
| Stations & chargers | List of owner's stations (city, charger count, status, today's revenue), add-station action | `GET /owner/stations`, `POST /owner/stations` |
| Settlements | Pending/last payout, platform fee %, next payout date, settlement history table (period, gross, commission, GST/TDS, net, status) | `GET /owner/settlements` |

Owner auth: role=owner, scoped so every query filters by `owner_id` server-side (never trust a client-supplied owner id).

## Admin Panel — screen map
| Prototype screen | Purpose | Backend calls |
|---|---|---|
| Dashboard | Platform-wide totals (users, stations, active chargers, revenue), cross-owner sessions feed | `GET /admin/dashboard`, `GET /admin/sessions` |
| Stations & owners | All stations across all owners (owner name, city, status), manage/suspend action | `GET /admin/stations`, `PATCH /admin/stations/{id}/status` |
| Settlement queue | All owners' settlement rows with process/approve action, status (pending/processing/paid) | `GET /admin/settlements`, `POST /admin/settlements/{id}/process` |

Admin auth: role=admin. Add the remaining admin surfaces named in the original spec but not yet prototyped — manage users, manage payments, coupons, pricing, support tickets, notifications — as additional routes under the same sidebar pattern once prioritized.

## Shared web-app notes
- Both portals share one component library/theme — build it once, gate routes by role via NextJS middleware checking the JWT role claim.
- Tables (stations, settlements, sessions) should support server-side pagination and filtering from day one — the prototype's static rows are for demonstration only.
- Status badges (Active/Maintenance/Suspended, Paid/Processing/Pending) use consistent color coding across both portals and the Flutter app's connector-status badges — define this as a single shared enum→color mapping, not per-screen logic.
- Charts (7-day activity) can start as a simple bar/line chart (e.g. Recharts) fed by the `analytics` rollup tables in `02-database-schema.md`.
