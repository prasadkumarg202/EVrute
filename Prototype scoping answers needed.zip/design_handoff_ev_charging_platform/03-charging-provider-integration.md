# 03 — Headless OCPP Provider Integration (ChargeLab / eDRV)

## What the provider owns
Charger connectivity, OCPP 1.6J/2.0.1, RemoteStartTransaction/RemoteStopTransaction, MeterValues, heartbeats, firmware updates, charger status, reservations, diagnostics. **Your platform never speaks OCPP or opens a WebSocket to a charger.**

## Account setup steps
1. Contact ChargeLab (chargelab.co) or eDRV (edrv.io) sales/partnerships to open a partner/API account. Request:
   - Sandbox environment with test chargers (both providers offer simulated chargers for OCPP 1.6J/2.0.1)
   - REST API credentials (API key or OAuth client credentials)
   - Webhook signing secret
2. Register your chargers/stations in the provider's dashboard (or via their onboarding API) so they appear under `GET /stations` in the provider's REST API — these are the provider-side records your `chargelab.adapter.ts`/`edrv.adapter.ts` will read and mirror into your own `stations`/`chargers`/`connectors` tables.
3. Configure the webhook endpoint URL in the provider dashboard to point at your `charging-webhooks.controller` (e.g. `https://api.yourdomain.com/webhooks/charging`), scoped to a non-production URL first (ngrok/staging) during integration testing.
4. Store the API key/OAuth secret and the webhook signing secret in AWS Secrets Manager; inject via environment variables (`CHARGING_PROVIDER_API_KEY`, `CHARGING_PROVIDER_WEBHOOK_SECRET`).
5. Confirm rate limits and required polling vs. webhook-driven status — prefer webhooks for status changes, poll `getLiveStatus` only as a fallback/reconciliation job.

## Webhooks to handle
```
Charging Started        → sessions.status = active
Charging Stopped        → sessions.status = completed, trigger invoice generation
Charging Failed         → sessions.status = failed, refund wallet hold, notify user
Payment Required        → notify user, block further remote-start until resolved
Fault Detected          → mark charger/connector faulted, notify owner + admin
Connector Offline       → connectors.status = offline
Connector Online        → connectors.status = available
Reservation Expired     → reservations.status = expired, free connector
Firmware Updated        → chargers.firmware_version updated
MeterValues             → sessions.energy_kwh updated, running cost recalculated
```
Every handler: verify signature → idempotency check (dedupe by provider event id) → update DB → emit internal domain event (for notifications/analytics) → 200 OK fast (queue heavy work via BullMQ, don't block the webhook response).

## Migration path (documented in code, not just here)
`ChargingProviderService` depends only on the `ChargingProvider` interface. Today it's bound to `ChargeLabAdapter` (or `EdrvAdapter`) via the Nest DI provider token. When the network justifies an in-house OCPP server (~1000+ chargers per the original spec), write an `InHouseOcppAdapter` implementing the same interface and swap the DI binding — zero changes required in `charging.service.ts`, controllers, or the Flutter app.
