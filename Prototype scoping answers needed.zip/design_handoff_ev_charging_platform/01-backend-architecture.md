# 01 — Backend Architecture (NestJS)

## Principles
- Clean Architecture / DDD, Repository Pattern, Dependency Injection (Nest's built-in DI container).
- **No OCPP, no WebSocket-to-charger code lives here.** All charger communication goes through a Headless OCPP Provider (ChargeLab or eDRV) via REST + webhooks.
- Every provider call is isolated behind `ChargingProviderService`, built against a `ChargingProvider` interface — swapping providers, or later replacing them with an in-house OCPP server, touches only the provider adapter module.

## Module layout
```
src/
  main.ts
  app.module.ts
  common/            # guards, interceptors, filters, decorators, pipes
  config/            # env schema + typed config service
  auth/              # signup, OTP, social login, JWT, RBAC (customer/owner/admin)
  users/
  vehicles/
  stations/          # station + charger + connector CRUD (platform-side metadata only)
  pricing/
  charging/
    charging.module.ts
    charging.controller.ts        # /session/start, /session/stop, /reservation
    charging.service.ts           # orchestrates session lifecycle, calls ChargingProviderService
    charging-provider/
      charging-provider.interface.ts   # ChargingProvider contract
      charging-provider.service.ts     # ChargingProviderService — the ONLY module allowed to call the vendor SDK/REST API
      adapters/
        chargelab.adapter.ts            # or edrv.adapter.ts — implements ChargingProvider
      webhooks/
        charging-webhooks.controller.ts # receives provider callbacks, verifies signature, re-emits internal events
  wallet/            # balance, recharge, debit/credit ledger
  payments/          # Razorpay/Cashfree order + payment capture
  settlements/       # settlement engine (see 05)
  invoices/
  favorites/
  reviews/
  notifications/     # Firebase push
  coupons/
  tickets/           # support tickets (owner/admin)
  analytics/
  database/          # TypeORM/Prisma entities + migrations
```

## ChargingProvider interface
```ts
export interface ChargingProvider {
  login(): Promise<void>;
  getStations(): Promise<ProviderStation[]>;
  getChargers(stationId: string): Promise<ProviderCharger[]>;
  getConnectors(chargerId: string): Promise<ProviderConnector[]>;
  getLiveStatus(connectorId: string): Promise<ConnectorStatus>;
  startCharging(connectorId: string, sessionCtx: SessionContext): Promise<ProviderSessionRef>;
  stopCharging(sessionRef: ProviderSessionRef): Promise<void>;
  reserveCharger(connectorId: string, window: ReservationWindow): Promise<ProviderReservationRef>;
  cancelReservation(reservationRef: ProviderReservationRef): Promise<void>;
  getSessionDetails(sessionRef: ProviderSessionRef): Promise<ProviderSessionDetails>;
  getMeterValues(sessionRef: ProviderSessionRef): Promise<MeterValue[]>;
  getChargingHistory(connectorId: string, range: DateRange): Promise<ProviderSessionDetails[]>;
  getFirmwareStatus(chargerId: string): Promise<FirmwareStatus>;
  getFaultStatus(chargerId: string): Promise<FaultStatus>;
  getConnectorStatus(connectorId: string): Promise<ConnectorStatus>;
  getPricing(connectorId: string): Promise<ProviderPricing>;
}
```

`ChargingProviderService` wraps the active adapter (selected by config: `CHARGING_PROVIDER=chargelab|edrv`), adds retries/circuit-breaking, logs every call, and translates provider DTOs into the platform's own domain models before returning them to `charging.service.ts`. **No controller, resolver, or frontend code calls an adapter directly — always go through `ChargingProviderService`.**

## Session start flow (server-side)
1. Customer app → `POST /session/start` (connectorId, vehicleId) → `charging.controller`
2. `charging.service` checks wallet balance ≥ estimated minimum, locks connector state in DB
3. `ChargingProviderService.startCharging()` → adapter → provider REST API → OCPP cloud → charger
4. Provider webhook `Charging Started` confirms; session row transitions `pending → active`
5. `MeterValues` webhooks stream in periodically; service updates `sessions.energy_kwh` and running cost
6. Stop (customer action or `Charging Stopped`/`Charging Failed` webhook) → session closes → invoice generated → settlement entry queued

## REST API (platform-facing, from spec)
```
POST   /auth/login
POST   /wallet/recharge
GET    /stations
GET    /station/{id}
GET    /connector/{id}
POST   /session/start
POST   /session/stop
POST   /reservation
DELETE /reservation
GET    /wallet
GET    /history
GET    /invoice
GET    /vehicle
GET    /favorites
```
Add standard owner/admin CRUD routes under `/owner/*` and `/admin/*` guarded by role-based auth (see `04` for the screens these back).

## Security checklist
- JWT access + refresh tokens; OTP rate-limited; social login via Firebase Auth or Auth0
- Role guard: customer / owner / admin / employee
- Webhook signature verification (HMAC secret from provider dashboard) — reject unsigned/invalid payloads
- Secrets in AWS Secrets Manager, never in repo
- Idempotency keys on `/session/start`, `/session/stop`, `/wallet/recharge`, and all webhook handlers
- Audit log table for settlement and payout actions
