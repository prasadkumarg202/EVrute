# Handoff: EV Charging Platform — Backend, Provider Integration, Flutter App, Payments

## Overview
This package hands off the four build tracks for the EV charging platform (customer app, owner portal, admin panel) prototyped in `EV Charging Platform Prototype.dc.html`:
1. NestJS backend + PostgreSQL schema
2. Headless OCPP provider (ChargeLab / eDRV) account setup & integration
3. Flutter mobile app build, using the HTML prototype as the UX reference
4. Razorpay / Cashfree payment + wallet + settlement wiring

## About the design file
`EV Charging Platform Prototype.dc.html` (included in this folder as `reference/`) is a **design reference**, not production code. It is an HTML/React prototype demonstrating screens, flows, copy, and interaction states for the customer app, owner portal, and admin panel. Recreate it in Flutter (mobile) and your web stack of choice (owner/admin — React 19 + NextJS per the original spec), using the platform's own component libraries — do not embed or ship the HTML.

## Fidelity
**Low-to-mid fidelity for visual polish, high-fidelity for flow and IA.** Colors/type in the prototype come from a placeholder design system (tap2news tokens — vermillion/navy/paper), used only to make the prototype presentable. Do NOT carry those exact colors into the production app unless your team adopts them — apply your own/product's brand system to the structure, copy, states, and flows shown.

## Read order
1. `01-backend-architecture.md` — NestJS module layout + ChargingProviderService abstraction
2. `02-database-schema.md` — PostgreSQL schema
3. `03-charging-provider-integration.md` — ChargeLab/eDRV account setup + webhook contract
4. `04-flutter-mobile-app.md` — customer app screen-by-screen UX spec
5. `05-payments-integration.md` — Razorpay/Cashfree + wallet + settlement engine
6. `06-owner-admin-web-portals.md` — owner portal + admin panel screen-by-screen UX spec

## Files
- `reference/EV Charging Platform Prototype.dc.html` — interactive UX prototype (open in any browser)
- Track docs 01–05 above
